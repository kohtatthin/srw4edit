"""ユニットデータの読み書き

V1.1 ROM準拠。可変長レコード（32B固定 + 武器セクション + 可変末尾）。

レコードフォーマット:
  +0  icon(1B), source_work(1B), graphic(2B)
  +4  fixed_pilot(1B), affiliation(1B), size_bgm(1B), transform(1B)
  +8  special_1(1B), special_2(1B), team(1B), unknown_11_15(5B)
  +16 repair_cost(2B LE), reward_money(2B LE)
  +20 move_range(1B), move_type(1B), terrain(2B LE)
  +24 armor(1B, ×10で実値), mobility(1B), limit_reaction(1B), en(1B)
  +28 hp(2B LE)
  +30 weapon_count(1B), unknown_31(1B)
  +32 武器セクション + 末尾 (可変)
"""

from __future__ import annotations

import importlib.resources as resources
import json
import struct
from pathlib import Path
from typing import Any

import yaml

from .models_units import TerrainRating, Unit, UnitCollection, WeaponSlot


# === 定数 ===
TABLE_START = 0x0B9571
TABLE_END = 0x0BD000

# 既知の確定オフセット (V1.1)
KNOWN_OFFSETS = {
    'ヒュッケバイン': 0x0B9571,
    'グルンガスト': 0x0B95A9,
    'ウイングガスト': 0x0B95DE,
    'ガストランダー': 0x0B9609,
    'νガンダム': 0x0B9634,
    'F-91': 0x0B966B,
    'ブルーガー': 0x0B9E85,
    'ダイモス': 0x0B9EB3,
    'ガルバーFXII': 0x0B9EFF,
    'ラーカイラム': 0x0BBC97,
    'Gディフェンサー': 0x0BC275,
    'ヌーベルディザード': 0x0BC423,
}

TERRAIN_NIBBLE_TO_RANK = {0: '-', 1: 'D', 2: 'C', 3: 'B', 4: 'A'}
TERRAIN_RANK_TO_NIBBLE = {v: k for k, v in TERRAIN_NIBBLE_TO_RANK.items()}


# === レコード発見 ===

def _make_pattern(u: dict) -> bytes:
    """参考データから +24〜+29 の6バイト一致パターンを生成"""
    return bytes([
        u['armor'] // 10,
        u['mobility'],
        u['limit_reaction'],
        u['en'],
        u['hp'] & 0xFF,
        (u['hp'] >> 8) & 0xFF,
    ])


def discover_unit_offsets(rom: bytes, reference: list[dict]) -> dict[str, int]:
    """ROM内の全ユニットレコード先頭オフセットを発見

    戦略:
    1. 既知オフセットをシード
    2. 参考データの+24〜+29 6Bパターン検索でユニーク確定
    3. 複数候補は近傍確定オフセットとの整合性で絞る
    """
    confirmed: dict[str, int] = {}
    # シード: 既知オフセットを参考データ名と照合
    ref_names = {u['name'] for u in reference}
    for known_name, offset in KNOWN_OFFSETS.items():
        if known_name in ref_names:
            confirmed[known_name] = offset
            continue
        # ゆらぎ吸収
        norm = known_name.replace('-', '').replace('・', '')
        for n in ref_names:
            if n.replace('-', '').replace('・', '') == norm:
                confirmed[n] = offset
                break

    # パターン検索
    candidates: dict[str, list[int]] = {}
    for u in reference:
        if u['name'] in confirmed:
            continue
        pat = _make_pattern(u)
        positions = []
        s = TABLE_START
        while s < TABLE_END:
            idx = rom.find(pat, s, TABLE_END)
            if idx < 0:
                break
            positions.append(idx - 24)  # +24 引いてレコード先頭に
            s = idx + 1
        if positions:
            candidates[u['name']] = positions

    # ユニーク確定
    for name, positions in candidates.items():
        if len(positions) == 1:
            confirmed[name] = positions[0]

    # 近傍整合で複数候補から選ぶ
    def plausible(off: int) -> bool:
        confirmed_sorted = sorted(confirmed.values())
        below = [c for c in confirmed_sorted if c < off]
        if not below:
            return False
        gap = off - below[-1]
        return 30 <= gap <= 130

    for name, positions in candidates.items():
        if name in confirmed:
            continue
        plausible_pos = [p for p in positions if plausible(p)]
        if len(plausible_pos) == 1:
            confirmed[name] = plausible_pos[0]

    return confirmed


def compute_record_sizes(confirmed: dict[str, int], rom: bytes) -> dict[str, int]:
    """確定オフセットから隣接差分でレコードサイズを決定。
    隣接差分が大きすぎる/最後のレコードは末尾 00 00 を探して決定。"""
    sorted_items = sorted(confirmed.items(), key=lambda x: x[1])
    sizes: dict[str, int] = {}
    MAX_REASONABLE_SIZE = 130

    def find_size_by_terminator(offset: int) -> int | None:
        """offset から最初の 00 00 を探してレコードサイズを返す"""
        end = min(offset + MAX_REASONABLE_SIZE, len(rom))
        for p in range(offset + 32, end - 1):
            if rom[p] == 0 and rom[p + 1] == 0:
                return (p + 2) - offset
        return None

    for i, (name, offset) in enumerate(sorted_items):
        if i + 1 < len(sorted_items):
            next_offset = sorted_items[i + 1][1]
            gap = next_offset - offset
            if gap <= MAX_REASONABLE_SIZE:
                sizes[name] = gap
            else:
                # 隣接が遠すぎる → 末尾00 00で再計算
                sz = find_size_by_terminator(offset)
                sizes[name] = sz if sz else 56
        else:
            # 最後: 末尾00 00で決定
            sz = find_size_by_terminator(offset)
            sizes[name] = sz if sz else 56
    return sizes


# === パース/シリアライズ ===

def _decode_terrain(word: int) -> TerrainRating:
    """地形適応2バイトを4nibbleで解釈
    順番: 空(高位) / 海 / 宇 / 陸(低位)
    """
    b1 = word & 0xFF
    b2 = (word >> 8) & 0xFF
    nibbles = [(b1 >> 4) & 0xF, b1 & 0xF, (b2 >> 4) & 0xF, b2 & 0xF]
    return TerrainRating(
        air=TERRAIN_NIBBLE_TO_RANK.get(nibbles[0], '-'),
        sea=TERRAIN_NIBBLE_TO_RANK.get(nibbles[1], '-'),
        space=TERRAIN_NIBBLE_TO_RANK.get(nibbles[2], '-'),
        land=TERRAIN_NIBBLE_TO_RANK.get(nibbles[3], '-'),
    )


def _encode_terrain(t: TerrainRating) -> int:
    """TerrainRating → 2バイト値"""
    nibbles = [
        TERRAIN_RANK_TO_NIBBLE[t.air],
        TERRAIN_RANK_TO_NIBBLE[t.sea],
        TERRAIN_RANK_TO_NIBBLE[t.space],
        TERRAIN_RANK_TO_NIBBLE[t.land],
    ]
    b1 = (nibbles[0] << 4) | nibbles[1]
    b2 = (nibbles[2] << 4) | nibbles[3]
    return b1 | (b2 << 8)


def _parse_weapon_section(tail: bytes) -> tuple[list[WeaponSlot], str, bool]:
    """武器セクション (3B/武器 + 余り + 00 00 sentinel) をパース。
    末尾 00 00 を除いた残りを 3B 区切りで WeaponSlot に分解。3で割り切れない場合の余りは
    weapon_extra_hex として保持し、シリアライズ時に同じ位置に戻す。
    sentinel の有無も返す（敵レコードの一部は sentinel なしの可能性に備える）。"""
    body = tail
    sentinel = body.endswith(b'\x00\x00')
    if sentinel:
        body = body[:-2]
    n_full = len(body) // 3
    slots: list[WeaponSlot] = []
    for i in range(n_full):
        b = body[i * 3:i * 3 + 3]
        v = b[0] | (b[1] << 8) | (b[2] << 16)
        slots.append(WeaponSlot(
            weapon_id=v & 0x3FF,
            ammo_id=(v >> 10) & 0x3F,
            custom_id=(v >> 16) & 0xFF,
        ))
    extra = body[n_full * 3:]
    return slots, extra.hex(), sentinel


def _serialize_weapon_section(slots: list[WeaponSlot], extra_hex: str, sentinel: bool = True) -> bytes:
    """WeaponSlot[] + 余り + sentinel → bytes"""
    out = bytearray()
    for s in slots:
        v = (s.weapon_id & 0x3FF) | ((s.ammo_id & 0x3F) << 10) | ((s.custom_id & 0xFF) << 16)
        out.append(v & 0xFF)
        out.append((v >> 8) & 0xFF)
        out.append((v >> 16) & 0xFF)
    if extra_hex:
        out.extend(bytes.fromhex(extra_hex))
    if sentinel:
        out.extend(b'\x00\x00')
    return bytes(out)


def parse_unit_record(rom: bytes, name: str, offset: int, size: int,
                      uid: int = -1, shared_uids: list[int] | None = None,
                      is_enemy: bool = False) -> Unit:
    """ROMからユニットレコード1個をパース"""
    end = offset + size
    tail = rom[offset + 32:end]
    weapon_slots, weapon_extra_hex, sentinel = _parse_weapon_section(tail)
    return Unit(
        name=name,
        offset=f'${offset:06X}',
        record_size=size,
        uid=uid,
        shared_uids=shared_uids or [],
        is_enemy=is_enemy,
        sentinel=sentinel,
        icon=rom[offset + 0],
        source_work=rom[offset + 1],
        graphic=struct.unpack('<H', rom[offset + 2:offset + 4])[0],
        fixed_pilot=rom[offset + 4],
        affiliation=rom[offset + 5],
        size_bgm=rom[offset + 6],
        transform=rom[offset + 7],
        special_1=rom[offset + 8],
        special_2=rom[offset + 9],
        team=rom[offset + 10],
        unknown_11_15_hex=rom[offset + 11:offset + 16].hex(),
        repair_cost=struct.unpack('<H', rom[offset + 16:offset + 18])[0],
        reward_money=struct.unpack('<H', rom[offset + 18:offset + 20])[0],
        move_range=rom[offset + 20],
        move_type=rom[offset + 21],
        terrain=_decode_terrain(struct.unpack('<H', rom[offset + 22:offset + 24])[0]),
        armor=rom[offset + 24] * 10,
        mobility=rom[offset + 25],
        limit_reaction=rom[offset + 26],
        en=rom[offset + 27],
        hp=struct.unpack('<H', rom[offset + 28:offset + 30])[0],
        weapon_count_field=rom[offset + 30],
        unknown_31=rom[offset + 31],
        weapon_slots=weapon_slots,
        weapon_extra_hex=weapon_extra_hex,
    )


def serialize_unit_record(unit: Unit) -> bytes:
    """Unit → ROMバイト列（書き戻し用）"""
    armor_byte = unit.armor // 10
    tail = _serialize_weapon_section(unit.weapon_slots, unit.weapon_extra_hex, unit.sentinel)
    parts = [
        bytes([unit.icon]),
        bytes([unit.source_work]),
        struct.pack('<H', unit.graphic),
        bytes([unit.fixed_pilot]),
        bytes([unit.affiliation]),
        bytes([unit.size_bgm]),
        bytes([unit.transform]),
        bytes([unit.special_1]),
        bytes([unit.special_2]),
        bytes([unit.team]),
        bytes.fromhex(unit.unknown_11_15_hex),
        struct.pack('<H', unit.repair_cost),
        struct.pack('<H', unit.reward_money),
        bytes([unit.move_range]),
        bytes([unit.move_type]),
        struct.pack('<H', _encode_terrain(unit.terrain)),
        bytes([armor_byte]),
        bytes([unit.mobility]),
        bytes([unit.limit_reaction]),
        bytes([unit.en]),
        struct.pack('<H', unit.hp),
        bytes([unit.weapon_count_field]),
        bytes([unit.unknown_31]),
        tail,
    ]
    result = b''.join(parts)
    expected = unit.record_size
    if len(result) != expected:
        raise ValueError(f'{unit.name}: serialized size {len(result)} != expected {expected}')
    return result


# === 高レベルAPI ===

def load_reference(reference_path: Path | None = None) -> list[dict]:
    """参考データ ally_units.yaml をロード"""
    if reference_path:
        with open(reference_path) as f:
            data = yaml.safe_load(f)
    else:
        text = (resources.files('srw4edit.data.reference') / 'ally_units.yaml').read_text()
        data = yaml.safe_load(text)
    return data['units']


# ユニット情報オフセット配列（2026-07-07 確定。RomMap.xml 由来、実ROM検証済み）
OFFSET_ARRAY = 0x0B9313
OFFSET_ARRAY_COUNT = 0x12F   # 303
BANK_BASE = 0x0B0000
DATA_START = 0x0B9571
DATA_LIMIT = 0x0BC950        # 武器情報オフセット配列の手前


def dump_units_full(rom: bytes) -> UnitCollection:
    """オフセット配列を正として全ユニット（敵含む297レコード）をパース。

    - レコードサイズは隣接オフセットとの差分（最終レコードのみ 00 00 終端探索）
    - 同一レコードを共有するIDは1件に集約し shared_uids に記録
    - 名前は ROM 内ユニット名テーブルを文字コード表で復号
    """
    from . import text as _text

    by_off: dict[int, list[int]] = {}
    for uid in range(OFFSET_ARRAY_COUNT):
        v = struct.unpack('<H', rom[OFFSET_ARRAY + uid * 2:OFFSET_ARRAY + uid * 2 + 2])[0]
        off = BANK_BASE + v
        if DATA_START <= off < DATA_LIMIT:
            by_off.setdefault(off, []).append(uid)

    names = _text.unit_names_from_rom(rom)
    try:
        ally_names = {u['name'] for u in load_reference()}
    except Exception:
        ally_names = set()

    sorted_offs = sorted(by_off)
    units = []
    seen_names: dict[str, int] = {}
    for i, off in enumerate(sorted_offs):
        if i + 1 < len(sorted_offs):
            size = sorted_offs[i + 1] - off
        else:
            # 最終レコード: 32B 以降で最初の 00 00 を探す
            size = 56
            for p in range(off + 32, min(off + 130, DATA_LIMIT) - 1):
                if rom[p] == 0 and rom[p + 1] == 0:
                    size = (p + 2) - off
                    break
        if size < 32 or size > 200:
            continue
        uids = by_off[off]
        uid = uids[0]
        name = names[uid] if uid < len(names) and names[uid] else f'U{uid:03X}'
        # 同名（形態違い等）はIDを付けて一意化
        if name in seen_names:
            name = f'{name} #{uid:03X}'
        seen_names[name] = uid
        units.append(parse_unit_record(
            rom, name, off, size,
            uid=uid, shared_uids=uids[1:],
            is_enemy=(names[uid] if uid < len(names) else '') not in ally_names,
        ))
    return UnitCollection(units=units)


def dump_units(rom: bytes, reference: list[dict] | None = None) -> UnitCollection:
    """ROMから全ユニットレコードをパース（オフセット配列ベース、敵含む）"""
    return dump_units_full(rom)


def apply_units(rom: bytes, collection: UnitCollection) -> bytes:
    """UnitCollectionの内容をROMに書き戻し、改変ROMを返す"""
    new_rom = bytearray(rom)
    for unit in collection.units:
        offset = int(unit.offset.lstrip('$'), 16)
        record_bytes = serialize_unit_record(unit)
        new_rom[offset:offset + unit.record_size] = record_bytes
    return bytes(new_rom)


def dump_to_yaml(rom: bytes, reference_path: Path | None = None) -> str:
    """YAML形式で全ユニットをdump"""
    collection = dump_units_full(rom)
    return yaml.safe_dump(
        collection.model_dump(),
        allow_unicode=True,
        sort_keys=False,
        width=200,
    )


def apply_from_yaml(rom: bytes, yaml_str: str) -> bytes:
    """YAML文字列からUnitCollectionを構築してROMに適用"""
    data = yaml.safe_load(yaml_str)
    collection = UnitCollection.model_validate(data)
    return apply_units(rom, collection)
