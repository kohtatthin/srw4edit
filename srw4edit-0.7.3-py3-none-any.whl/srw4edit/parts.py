"""強化パーツデータの読み書き

テーブル（2026-07-07 実ROM検証済み。v2/v3メモの 0xB850 系は誤りだった）:
  0x0DF85C: 4B×24 = (移動力, 運動性, 限界反応, 装甲) 各1B
  0x0DF8BC: 4B×24 = (HP 2B LE, バリア種別 2B LE)

バリア種別: 0=なし / 1=ビームコート / 2=Iフィールド / 3=オーラバリア / 4=ビームバリア(没)
バリア強度は別テーブル 0x03F174 (2B×8)、消費EN 0x03E116 (2B×8)。
枠 0x0D「バリアジェネレーター」は没パーツ（バリア種別4=ビームバリア2500 実装済み）。
"""

from __future__ import annotations

import struct

from pydantic import BaseModel, ConfigDict, Field

TABLE_A = 0x0DF85C   # 移動/運動/限界/装甲
TABLE_B = 0x0DF8BC   # HP/バリア
PART_COUNT = 24

PART_NAMES = [
    '高性能レーダー', 'ミノフスキークラフト', 'ブースター', 'メガブースター',
    'アポジモーター', 'ファティマ', 'ALICE', 'サイコフレーム',
    'バイオセンサー', 'マグネットコーティング', 'Iフィールド発生器', 'チョバムアーマー',
    'ハイブリッドアーマー', 'バリアジェネレーター(没)', '対ビームコーティング', 'リペアキット',
    'プロペラントタンク', 'プロペラントタンクS',
] + [f'空き枠{i}' for i in range(1, 7)]

BARRIER_NAMES = {0: 'なし', 1: 'ビームコート', 2: 'Iフィールド', 3: 'オーラバリア', 4: 'ビームバリア'}

BARRIER_POWER = 0x03F174   # 2B×8 バリア強度
BARRIER_EN = 0x03E116      # 2B×8 バリア消費EN


class Part(BaseModel):
    model_config = ConfigDict(extra='ignore')
    part_id: int = Field(..., ge=0, le=23)
    name: str
    move: int = Field(..., ge=0, le=255, description='移動力+')
    mobility: int = Field(..., ge=0, le=255, description='運動性+')
    limit_reaction: int = Field(..., ge=0, le=255, description='限界反応+')
    armor: int = Field(..., ge=0, le=255, description='装甲+ (ROM生値。ゲーム内表示は×10)')
    hp: int = Field(..., ge=0, le=65535, description='HP+')
    barrier_type: int = Field(..., ge=0, le=65535, description='バリア種別 (0-4)')


class PartCollection(BaseModel):
    model_config = ConfigDict(extra='ignore')
    parts: list[Part]
    barrier_power: list[int] = Field(default_factory=list, description='バリア強度テーブル (種別1-4が実効)')
    barrier_en: list[int] = Field(default_factory=list, description='バリア消費ENテーブル')


def read_parts(rom: bytes) -> PartCollection:
    parts = []
    for i in range(PART_COUNT):
        a = TABLE_A + i * 4
        b = TABLE_B + i * 4
        mv, mob, lim, arm = rom[a:a + 4]
        hp, barrier = struct.unpack('<HH', rom[b:b + 4])
        parts.append(Part(part_id=i, name=PART_NAMES[i], move=mv, mobility=mob,
                          limit_reaction=lim, armor=arm, hp=hp, barrier_type=barrier))
    return PartCollection(
        parts=parts,
        barrier_power=[struct.unpack_from('<H', rom, BARRIER_POWER + i * 2)[0] for i in range(8)],
        barrier_en=[struct.unpack_from('<H', rom, BARRIER_EN + i * 2)[0] for i in range(8)],
    )


def apply_parts(rom: bytes, coll: PartCollection) -> bytes:
    out = bytearray(rom)
    for p in coll.parts:
        a = TABLE_A + p.part_id * 4
        b = TABLE_B + p.part_id * 4
        out[a:a + 4] = bytes([p.move, p.mobility, p.limit_reaction, p.armor])
        out[b:b + 4] = struct.pack('<HH', p.hp, p.barrier_type)
    for i, v in enumerate(coll.barrier_power[:8]):
        struct.pack_into('<H', out, BARRIER_POWER + i * 2, v)
    for i, v in enumerate(coll.barrier_en[:8]):
        struct.pack_into('<H', out, BARRIER_EN + i * 2, v)
    return bytes(out)
