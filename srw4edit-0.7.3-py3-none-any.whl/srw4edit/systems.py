"""システム定数・戦闘式係数の読み書き（2026-07-07 全域解読で確定したテーブル群）

  0x00A417: 2回行動に必要な直感値 (1B) ※表示用の複製が 0x00CF78 / 0x02DF84 にあり、3箇所同時書き換え
  0x00B1BD: 精神コマンド消費SP (1B×32)
  0x03F164: クリティカル補正・実効値 (s16×8) ※表示用複製 0x00B615 と同時書き換え
  0x00B9F1: 地形適応倍率 (2B×5 = -/C/B/A/S 想定)
  0x03F4F9: 武器地形適応倍率 (1B×4 = -/C/B/A)
  0x03F442: サイズ差補正 (2B×4)

限界キャップ撤廃パッチ（hit-rate-cap-plan 2026-05-20 のB案をトグル化）:
  戦闘予測ルーチンの「min(能力+運動性, 機体限界)」クランプ4箇所を固定255に置換。
  ※静的検証済み・実機長時間プレイでの検証は未了（実験的機能）
"""

from __future__ import annotations

import struct

from pydantic import BaseModel, ConfigDict, Field

DOUBLE_ACT = [0x00A417, 0x00CF78, 0x02DF84]   # 判定 / 移動後表示 / Wマーク表示
SPIRIT_SP = 0x00B1BD
CRIT_EFFECTIVE = 0x03F164
CRIT_DISPLAY = 0x00B615
TERRAIN_MULT = 0x00B9F1
WEAPON_TERRAIN_MULT = 0x03F4F9
SIZE_MOD = 0x03F442

SPIRIT_NAMES = ['無し', '根性', 'ド根性', '補給', '友情', '信頼', '愛', '激怒', '気合', '加速',
                '熱血', '必中', 'ひらめき', '幸運', '覚醒', '威圧', 'てかげん', '集中', '激励',
                '再動', '復活', '隠れ身', '脱力', '自爆', '探索', '足かせ', 'かく乱', '偵察',
                '鉄壁', '魂', '奇跡']

# 限界キャップ撤廃パッチ（B案）: 4箇所×10B
_LIMIT_SITES = [0x03E366, 0x03E37E, 0x03E901, 0x03E919]
_LIMIT_OLD = [bytes.fromhex('b005d9661b9003b9661b'),   # Y版
              bytes.fromhex('b005dd661b9003bd661b')]   # X版
_LIMIT_NEW = bytes.fromhex('b004c9ff9002a9ffeaea')     # LDA #$FF 固定化

# 底力（2026-07-08 解析）: ルーチン $03F260
#   発動条件 = 現HP ≤ 最大HP >> LSR回数（素は LSR×3 = 1/8。ほぼ瀕死でしか発動しない）
#   効果     = クリティカル率 + 定数（素 +50、0x03F2A1 の 2B）
#   判定     = 技能ID 0x30 完全一致（Lv概念なし。0x32=聖戦士/0x3E=NT/0x3F=強化人間は別技能）
_GUTS_LSR = [0x03F264, 0x03F265, 0x03F266]   # 4A=LSR / EA=NOP
_GUTS_BONUS = 0x03F2A1                        # ADC #$xxxx のオペランド


class SystemSettings(BaseModel):
    model_config = ConfigDict(extra='ignore')
    double_act_intuition: int = Field(..., ge=1, le=255, description='2回行動に必要な直感値 (素130)')
    spirit_sp: list[int] = Field(..., min_length=31, max_length=31, description='精神消費SP (ID 0-30)')
    critical_mod: list[int] = Field(..., min_length=5, max_length=5, description='クリティカル補正 -10〜+30 の5段')
    terrain_mult: list[int] = Field(..., min_length=5, max_length=5, description='地形適応倍率 (素 [0,60,80,100,120])')
    weapon_terrain_mult: list[int] = Field(..., min_length=4, max_length=4, description='武器地形倍率 (素 [0,40,70,100])')
    size_mod: list[int] = Field(..., min_length=4, max_length=4, description='サイズ差補正 (素 [80,100,120,140])')
    limit_cap_removed: bool = Field(..., description='限界キャップ撤廃パッチ (実験的。命中回避のクランプを固定255へ)')
    guts_hp_divisor: int = Field(..., description='底力の発動HP条件: 最大HPの 1/N (素8=瀕死限定。4でシリーズ通例の1/4)')
    guts_crit_bonus: int = Field(..., ge=0, le=255, description='底力発動時のクリティカル率加算 (素50)')


def _limit_patch_state(rom: bytes) -> bool | None:
    """True=適用済 / False=未適用 / None=どちらでもない（想定外ROM）"""
    states = []
    for a in _LIMIT_SITES:
        chunk = rom[a:a + 10]
        if chunk == _LIMIT_NEW:
            states.append(True)
        elif chunk in _LIMIT_OLD:
            states.append(False)
        else:
            return None
    if all(states):
        return True
    if not any(states):
        return False
    return None


def _read_guts_divisor(rom: bytes) -> int:
    n = sum(1 for a in _GUTS_LSR if rom[a] == 0x4A)
    return 1 << n if all(rom[a] in (0x4A, 0xEA) for a in _GUTS_LSR) else 8


def read_systems(rom: bytes) -> SystemSettings:
    return SystemSettings(
        guts_hp_divisor=_read_guts_divisor(rom),
        guts_crit_bonus=struct.unpack_from('<H', rom, _GUTS_BONUS)[0],
        double_act_intuition=rom[DOUBLE_ACT[0]],
        spirit_sp=list(rom[SPIRIT_SP:SPIRIT_SP + 31]),
        critical_mod=[struct.unpack_from('<h', rom, CRIT_EFFECTIVE + i * 2)[0] for i in range(5)],
        terrain_mult=[struct.unpack_from('<H', rom, TERRAIN_MULT + i * 2)[0] for i in range(5)],
        weapon_terrain_mult=list(rom[WEAPON_TERRAIN_MULT:WEAPON_TERRAIN_MULT + 4]),
        size_mod=[struct.unpack_from('<H', rom, SIZE_MOD + i * 2)[0] for i in range(4)],
        limit_cap_removed=_limit_patch_state(rom) is True,
    )


def apply_systems(rom: bytes, s: SystemSettings) -> bytes:
    out = bytearray(rom)
    for a in DOUBLE_ACT:
        out[a] = s.double_act_intuition
    out[SPIRIT_SP:SPIRIT_SP + 31] = bytes(s.spirit_sp[:31])
    for i, v in enumerate(s.critical_mod[:5]):
        struct.pack_into('<h', out, CRIT_EFFECTIVE + i * 2, v)
        struct.pack_into('<h', out, CRIT_DISPLAY + i * 2, v)   # 表示側も同期
    for i, v in enumerate(s.terrain_mult[:5]):
        struct.pack_into('<H', out, TERRAIN_MULT + i * 2, v)
    out[WEAPON_TERRAIN_MULT:WEAPON_TERRAIN_MULT + 4] = bytes(s.weapon_terrain_mult[:4])
    for i, v in enumerate(s.size_mod[:4]):
        struct.pack_into('<H', out, SIZE_MOD + i * 2, v)

    # 底力: 発動条件（LSR回数）とクリ補正
    if s.guts_hp_divisor in (2, 4, 8) and all(out[a] in (0x4A, 0xEA) for a in _GUTS_LSR):
        n = {2: 1, 4: 2, 8: 3}[s.guts_hp_divisor]
        for i, a in enumerate(_GUTS_LSR):
            out[a] = 0x4A if i < n else 0xEA
    struct.pack_into('<H', out, _GUTS_BONUS, s.guts_crit_bonus)

    # 限界キャップパッチのトグル
    cur = _limit_patch_state(bytes(out))
    if cur is not None and cur != s.limit_cap_removed:
        for a in _LIMIT_SITES:
            if s.limit_cap_removed:
                out[a:a + 10] = _LIMIT_NEW
            else:
                # 復元: Y版/X版はサイトで固定（0x03E366/0x03E901=Y, 0x03E37E/0x03E919=X）
                orig = _LIMIT_OLD[0] if a in (0x03E366, 0x03E901) else _LIMIT_OLD[1]
                out[a:a + 10] = orig
    return bytes(out)
