"""改造システムのテーブル読み書き（2026-07-07 実ROM検証済み）

  0x009837: 改造強化値      16B×5行 = ステ別(HP/EN/装甲/運動性/限界反応) × 段階0-7 (2B)
  0x0DF366: ユニット改造費用 10B×7段階 = (HP, EN, 装甲, 運動性, 限界反応) 各2B
  0x0DF3B6: 武器改造費用    16B×7段階 = 8列 (バルカン/ハイパー/レール/未使用×4/一般) 各2B

注: v3メモの「0x02D81F=武器威力上昇量+200」は誤り（実際は LDA $7F7800,X 命令の一部）。
武器改造の上昇量テーブルは未特定のため本モジュールでは扱わない。
"""

from __future__ import annotations

import struct

from pydantic import BaseModel, ConfigDict, Field

UPGRADE_VALUES = 0x009837
UNIT_COSTS = 0x0DF366
WEAPON_COSTS = 0x0DF3B6

STAT_NAMES = ['HP', 'EN', '装甲', '運動性', '限界反応']
WEAPON_COST_COLS = ['バルカン系', 'ハイパー系', 'レールガン系', '未使用1', '未使用2', '未使用3', '未使用4', '一般']


class Modifications(BaseModel):
    model_config = ConfigDict(extra='ignore')
    # 改造強化値: stat名 → 段階0-7 の累積上昇量 (ROM生値)
    upgrade_values: dict[str, list[int]] = Field(..., description='ステ別 段階0-7 上昇量 (2B×8)')
    # ユニット改造費用: 段階1-7 × 5ステ
    unit_costs: list[list[int]] = Field(..., description='段階1-7 × [HP,EN,装甲,運動,限界]')
    # 武器改造費用: 段階1-7 × 8列
    weapon_costs: list[list[int]] = Field(..., description='段階1-7 × 8列(改造費テーブルID順)')


def read_modifications(rom: bytes) -> Modifications:
    upgrade = {}
    for i, stat in enumerate(STAT_NAMES):
        base = UPGRADE_VALUES + i * 16
        upgrade[stat] = [struct.unpack_from('<H', rom, base + j * 2)[0] for j in range(8)]
    unit_costs = [[struct.unpack_from('<H', rom, UNIT_COSTS + s * 10 + j * 2)[0] for j in range(5)]
                  for s in range(7)]
    weapon_costs = [[struct.unpack_from('<H', rom, WEAPON_COSTS + s * 16 + j * 2)[0] for j in range(8)]
                    for s in range(7)]
    return Modifications(
        upgrade_values=upgrade,
        unit_costs=unit_costs,
        weapon_costs=weapon_costs,
    )


def apply_modifications(rom: bytes, m: Modifications) -> bytes:
    out = bytearray(rom)
    for i, stat in enumerate(STAT_NAMES):
        base = UPGRADE_VALUES + i * 16
        for j, v in enumerate(m.upgrade_values[stat][:8]):
            struct.pack_into('<H', out, base + j * 2, v)
    for s in range(min(7, len(m.unit_costs))):
        for j, v in enumerate(m.unit_costs[s][:5]):
            struct.pack_into('<H', out, UNIT_COSTS + s * 10 + j * 2, v)
    for s in range(min(7, len(m.weapon_costs))):
        for j, v in enumerate(m.weapon_costs[s][:8]):
            struct.pack_into('<H', out, WEAPON_COSTS + s * 16 + j * 2, v)
    return bytes(out)
