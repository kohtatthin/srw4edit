"""ROMファイルの読み書きユーティリティ"""

from __future__ import annotations

from pathlib import Path


SRW4_V11_SIZE = 3_145_728  # 3MB, 第4次スーパーロボット大戦 V1.1


def load_rom(path: Path | str) -> bytes:
    """ROMファイルを全体読み込み"""
    p = Path(path)
    data = p.read_bytes()
    if len(data) != SRW4_V11_SIZE:
        # ヘッダ付き(.smc)の場合は512バイト剥がす
        if len(data) == SRW4_V11_SIZE + 512:
            data = data[512:]
        else:
            raise ValueError(
                f"ROM size mismatch: expected {SRW4_V11_SIZE} bytes, got {len(data)}. "
                "V1.1 ROM (3MB) を指定してください。"
            )
    return data


def save_rom(path: Path | str, data: bytes) -> None:
    """ROMバイト列をファイルに書き出し"""
    if len(data) != SRW4_V11_SIZE:
        raise ValueError(f"ROMサイズ異常: {len(data)} bytes（期待値 {SRW4_V11_SIZE}）")
    Path(path).write_bytes(data)


def patch_bytes(data: bytes, offset: int, new_bytes: bytes) -> bytes:
    """指定オフセットにバイト列を書き込んだ新しいbytesを返す（元データは不変）"""
    if offset + len(new_bytes) > len(data):
        raise ValueError("書き込み範囲がROMサイズを超えています")
    return data[:offset] + new_bytes + data[offset + len(new_bytes):]
