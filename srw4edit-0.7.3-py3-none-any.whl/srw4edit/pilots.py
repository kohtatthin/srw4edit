"""パイロットデータの読み書き

V1.1 ROM準拠。33バイト基本フォーマット。
"""

from __future__ import annotations

import importlib.resources as resources
from pathlib import Path
from typing import Any

import yaml

from .models import (
    GrowthRates,
    Personality,
    Pilot,
    PilotCollection,
    SpecialSkill,
    SpiritCommand,
    TerrainAdaptation,
    TerrainProfile,
)
from .rom import load_rom, patch_bytes, save_rom


# パイロットレコードのフォーマット定義
# offset, field_name, size_in_bytes
PILOT_FIELDS = [
    (0, "face_id", 1),
    (1, "source_work", 1),
    (2, "affiliation", 1),
    (3, "defeat_exp", 1),
    (4, "hit_skill_growth", 1),       # 命中・技量
    (5, "atk_growth", 1),              # 近・遠攻撃
    (6, "sp_growth", 1),               # SP成長
    (7, "evd_int_growth", 1),          # 回避・直感
    (8, "terrain_byte_1", 1),          # 地形バイト1
    (9, "terrain_byte_2", 1),          # 地形バイト2
    (10, "melee_attack", 1),
    (11, "ranged_attack", 1),
    (12, "accuracy", 1),
    (13, "skill", 1),
    (14, "evasion", 1),
    (15, "intuition", 1),
    (16, "sp", 1),
    # 17-28: 精神コマンド 12バイト (ID 1B + Lv 1B) × 6
    # 29-34: 特殊技能 6バイト (ID 1B + Lv 1B) × 3
]

RECORD_SIZE = 35  # 基本サイズ（顔1+作品1+所属1+EXP1+成長4+地形2+ステ7+精神12+技能6 = 35）


def _load_yaml_resource(filename: str) -> dict[Any, Any]:
    """data/ 配下のYAMLリソースを読み込む"""
    pkg = resources.files("srw4edit.data")
    return yaml.safe_load((pkg / filename).read_text(encoding="utf-8"))


def _spirit_id_to_name() -> dict[int, str]:
    raw = _load_yaml_resource("spirits.yaml")
    return {int(k): v for k, v in raw.items() if not str(k).startswith("#")}


def _skill_id_to_name() -> dict[int, str]:
    raw = _load_yaml_resource("skills.yaml")
    return {int(k): v for k, v in raw.items() if not str(k).startswith("#")}


def _pilot_offsets() -> dict[str, int]:
    """パイロット名→ROMオフセットのマップ（別名も含む）"""
    raw = _load_yaml_resource("pilot_offsets.yaml")
    offsets = {name: int(off) for name, off in raw["pilots"].items()}
    # 別名も同じオフセットを指すように展開
    aliases = raw.get("aliases", {}) or {}
    for alias, canonical in aliases.items():
        if canonical in offsets:
            offsets[alias] = offsets[canonical]
    return offsets


# 性格バイトの解釈
# TODO: 正確なエンコーディングは要解析。とりあえずダミー実装
PERSONALITY_FROM_BYTE = {
    # 性格データの正確なバイト位置とエンコーディングは要追加解析
    # 暫定的に「強気」をデフォルトとする
}


def _decode_terrain(byte1: int, byte2: int) -> TerrainProfile:
    """地形適応2バイトをパース

    エンコーディング（V1.1実ROMから判明）:
    - byte1 high nibble: 空
    - byte1 low nibble: 海
    - byte2 high nibble: 宇
    - byte2 low nibble: 陸
    - ランク: A=4, B=3, C=2, D=1, -=0 (推定), S=5 (推定)
    """
    rank_map = {
        0x0: TerrainAdaptation.NONE,
        0x1: TerrainAdaptation.D,
        0x2: TerrainAdaptation.C,
        0x3: TerrainAdaptation.B,
        0x4: TerrainAdaptation.A,
        0x5: TerrainAdaptation.S,
    }
    air = rank_map.get(byte1 >> 4, TerrainAdaptation.NONE)
    sea = rank_map.get(byte1 & 0xF, TerrainAdaptation.NONE)
    space = rank_map.get(byte2 >> 4, TerrainAdaptation.NONE)
    land = rank_map.get(byte2 & 0xF, TerrainAdaptation.NONE)
    return TerrainProfile(air=air, land=land, sea=sea, space=space)


def _encode_terrain(profile: TerrainProfile) -> tuple[int, int]:
    """TerrainProfile → 2バイト（_decode_terrain の逆変換）"""
    rank_to_nibble = {
        TerrainAdaptation.NONE: 0x0,
        TerrainAdaptation.D: 0x1,
        TerrainAdaptation.C: 0x2,
        TerrainAdaptation.B: 0x3,
        TerrainAdaptation.A: 0x4,
        TerrainAdaptation.S: 0x5,
    }
    byte1 = (rank_to_nibble[profile.air] << 4) | rank_to_nibble[profile.sea]
    byte2 = (rank_to_nibble[profile.space] << 4) | rank_to_nibble[profile.land]
    return byte1, byte2


def read_pilot_at(rom_data: bytes, offset: int, name: str = "") -> Pilot:
    """ROMの指定オフセットからパイロット1体を読み出す"""
    spirit_map = _spirit_id_to_name()
    skill_map = _skill_id_to_name()

    record = rom_data[offset:offset + RECORD_SIZE]
    if len(record) < RECORD_SIZE:
        raise ValueError(f"レコード読み出し失敗: offset=${offset:06X}")

    # フォーマット仕様（実ROM解析で判明）:
    # offset 17から (ID, Lv) のペアを最大9エントリ並べる「統一リスト」構造
    # - ID $01-$1E: 精神コマンド
    # - ID $20-$3F: 特殊技能
    # - ID $00: 終端子 (リストが9未満の場合のみ存在)
    spirits: list[SpiritCommand] = []
    skills: list[SpecialSkill] = []
    entry_count = 0
    for i in range(9):
        pos = 17 + i * 2
        if pos + 1 >= len(record):
            break
        eid = record[pos]
        elv = record[pos + 1]
        if eid == 0:
            break
        entry_count = i + 1
        if eid in spirit_map and elv <= 99:
            spirits.append(SpiritCommand(name=spirit_map[eid], learn_level=elv))
        elif eid in skill_map and elv <= 99:
            skill_full = skill_map[eid]
            if "Lv" in skill_full:
                sk_name, _, sk_lv_str = skill_full.rpartition("Lv")
                sk_lv = int(sk_lv_str)
            else:
                sk_name = skill_full
                sk_lv = 1
            skills.append(SpecialSkill(name=sk_name, skill_level=sk_lv, learn_level=elv))
        else:
            # 未知ID（主人公の特殊データ等）
            if eid < 0x20:
                spirits.append(SpiritCommand(name=f"未知ID${eid:02X}", learn_level=elv))
            else:
                # 技能未知IDは技能扱い
                skills.append(SpecialSkill(name=f"未知ID${eid:02X}", skill_level=1, learn_level=elv))

    terrain = _decode_terrain(record[8], record[9])

    # 実レコードサイズ: 17 + entry_count*2 + (2 if entry_count < 9 else 0)
    actual_record_size = 17 + entry_count * 2
    if entry_count < 9:
        actual_record_size += 2  # 終端子

    return Pilot(
        name=name or f"unnamed_{offset:06X}",
        rom_offset=offset,
        record_size=actual_record_size,
        face_id=record[0],
        source_work=record[1],
        affiliation=record[2],
        defeat_exp=record[3],
        personality=Personality.AGGRESSIVE,  # TODO: 性格バイトの解釈要検証
        growth=GrowthRates(
            melee_far_packed=record[5],
            hit_skill_packed=record[4],
            sp_growth=record[6],
            evasion_intuition_packed=record[7],
        ),
        terrain=terrain,
        melee_attack=record[10],
        ranged_attack=record[11],
        accuracy=record[12],
        skill=record[13],
        evasion=record[14],
        intuition=record[15],
        sp=record[16],
        spirits=spirits,
        skills=skills,
    )


def write_pilot(rom_data: bytes, pilot: Pilot) -> bytes:
    """Pilot を ROMバイトに書き戻し、新しい bytes を返す

    実際に書き込むバイト数は pilot.record_size を尊重する
    （技能数によって29〜35バイト可変）。
    """
    spirit_name_to_id = {v: k for k, v in _spirit_id_to_name().items()}
    skill_name_to_id = {v: k for k, v in _skill_id_to_name().items()}

    # 最大35バイトのバッファに作って、最後にrecord_size分だけ切り出す
    new_record = bytearray(35)
    new_record[0] = pilot.face_id
    new_record[1] = pilot.source_work
    new_record[2] = pilot.affiliation
    new_record[3] = pilot.defeat_exp
    new_record[4] = pilot.growth.hit_skill_packed
    new_record[5] = pilot.growth.melee_far_packed
    new_record[6] = pilot.growth.sp_growth
    new_record[7] = pilot.growth.evasion_intuition_packed
    new_record[8], new_record[9] = _encode_terrain(pilot.terrain)
    new_record[10] = pilot.melee_attack
    new_record[11] = pilot.ranged_attack
    new_record[12] = pilot.accuracy
    new_record[13] = pilot.skill
    new_record[14] = pilot.evasion
    new_record[15] = pilot.intuition
    new_record[16] = pilot.sp

    # 精神コマンド（可変数。pilot.spiritsの実数だけ書き出す）
    spirit_count = len(pilot.spirits[:6])
    for i, sp in enumerate(pilot.spirits[:6]):
        # 未知IDをそのまま保持する（"未知ID$XX" → 0xXX）
        if sp.name.startswith("未知ID$"):
            try:
                sid: int | None = int(sp.name[len("未知ID$"):], 16)
            except ValueError:
                sid = None
        else:
            sid = spirit_name_to_id.get(sp.name)
        if sid is None:
            raise ValueError(f"未知の精神コマンド: {sp.name}")
        new_record[17 + i * 2] = sid
        new_record[18 + i * 2] = sp.learn_level

    # 統一リスト書き込み: 精神 → 技能 の順に並べる
    # 主人公等の特殊ケースは spirits/skills 計9エントリまで
    spirit_count = len(pilot.spirits[:9])
    skill_count = len(pilot.skills[:9])
    entry_count = spirit_count + skill_count
    if entry_count > 9:
        raise ValueError(f"{pilot.name}: 精神+技能の合計は9エントリまで (現在{entry_count})")

    # 精神コマンド先頭から並べる
    for i, sp in enumerate(pilot.spirits[:9]):
        if sp.name.startswith("未知ID$"):
            try:
                sid: int | None = int(sp.name[len("未知ID$"):], 16)
            except ValueError:
                sid = None
        else:
            sid = spirit_name_to_id.get(sp.name)
        if sid is None:
            raise ValueError(f"未知の精神コマンド: {sp.name}")
        new_record[17 + i * 2] = sid
        new_record[18 + i * 2] = sp.learn_level

    # 技能を精神の直後に配置
    skill_offset_start = 17 + spirit_count * 2
    for i, sk in enumerate(pilot.skills[:9]):
        full_name = f"{sk.name}Lv{sk.skill_level}"
        sid_int = skill_name_to_id.get(full_name)
        if sid_int is None and sk.name.startswith("未知ID$"):
            try:
                sid_int = int(sk.name[len("未知ID$"):], 16)
            except ValueError:
                sid_int = None
        if sid_int is None:
            raise ValueError(f"未知の技能: {full_name}")
        new_record[skill_offset_start + i * 2] = sid_int
        new_record[skill_offset_start + i * 2 + 1] = sk.learn_level

    # 実レコードサイズ
    actual_size = 17 + entry_count * 2
    if entry_count < 9:
        actual_size += 2  # 終端子

    return patch_bytes(rom_data, pilot.rom_offset, bytes(new_record[:actual_size]))


def read_all_pilots(rom_data: bytes) -> PilotCollection:
    """設定済みオフセット表に基づいて全パイロットを読み込み（別名は除外）"""
    raw = _load_yaml_resource("pilot_offsets.yaml")
    # 正規名のみ使用（別名はAlias扱いで重複読み込みを避ける）
    pilot_offsets = {name: int(off) for name, off in raw["pilots"].items()}
    pilots = []
    for name, offset in pilot_offsets.items():
        try:
            pilot = read_pilot_at(rom_data, offset, name=name)
            pilots.append(pilot)
        except Exception as e:
            print(f"WARN: {name} の読み込みに失敗: {e}")
    return PilotCollection(rom_version="V1.1", pilots=pilots)


def write_all_pilots(rom_data: bytes, collection: PilotCollection) -> bytes:
    """全パイロットをROMに書き戻し"""
    result = rom_data
    for pilot in collection.pilots:
        result = write_pilot(result, pilot)
    return result


def dump_to_yaml(rom_path: Path | str, out_path: Path | str) -> None:
    """ROM → YAML"""
    rom = load_rom(rom_path)
    collection = read_all_pilots(rom)
    Path(out_path).write_text(
        yaml.safe_dump(
            collection.model_dump(mode="json"),
            allow_unicode=True,
            sort_keys=False,
        ),
        encoding="utf-8",
    )


def apply_from_yaml(rom_path: Path | str, yaml_path: Path | str, out_path: Path | str) -> None:
    """YAML編集内容をROMに適用"""
    rom = load_rom(rom_path)
    data = yaml.safe_load(Path(yaml_path).read_text(encoding="utf-8"))
    collection = PilotCollection.model_validate(data)
    new_rom = write_all_pilots(rom, collection)
    save_rom(out_path, new_rom)
