"""データモデル定義（Pydantic）"""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class Personality(str, Enum):
    """パイロットの性格（仲間撃墜時の気力増減に影響）"""
    SUPER_AGGRESSIVE = "超強気"   # +2
    AGGRESSIVE = "強気"            # +1
    NORMAL = "普通"                # 0
    WEAK = "弱気"                  # -1
    SUPER_WEAK = "超弱気"          # -1


class TerrainAdaptation(str, Enum):
    """地形適応"""
    S = "S"
    A = "A"
    B = "B"
    C = "C"
    D = "D"
    NONE = "-"


class SpiritCommand(BaseModel):
    """精神コマンドのスロット"""
    name: str  # "熱血", "魂"など
    learn_level: int = Field(ge=0, le=99, description="習得Lv")


class SpecialSkill(BaseModel):
    """特殊技能のスロット"""
    name: str  # "ニュータイプ", "聖戦士"など
    skill_level: int = Field(ge=1, le=8, description="技能Lv（切り払い・シールド防御など）")
    learn_level: int = Field(ge=1, le=99, description="習得Lv")


class TerrainProfile(BaseModel):
    """4方向の地形適応"""
    air: TerrainAdaptation
    land: TerrainAdaptation
    sea: TerrainAdaptation
    space: TerrainAdaptation


class GrowthRates(BaseModel):
    """成長率（各値の小さい/大きいフラグ）

    GCGXでは「攻0〜攻8」など段階指定だが、ROMでは
    パックされた1バイトを上位/下位ニブルに分けて格納。
    """
    melee_far_packed: int = Field(ge=0, le=0xFF, description="近・遠攻撃成長度合い")
    hit_skill_packed: int = Field(ge=0, le=0xFF, description="命中・技量成長度合い")
    sp_growth: int = Field(ge=0, le=0xFF, description="SP成長（00=2ずつ, 10=3ずつ, 20=なし, 30=1ずつ）")
    evasion_intuition_packed: int = Field(ge=0, le=0xFF, description="回避・直感成長度合い")


class Pilot(BaseModel):
    """パイロット1体分のデータ"""

    name: str
    rom_offset: int = Field(description="ROMファイル上の開始オフセット")
    record_size: int = Field(default=33, description="このレコードのバイト長")

    # 識別子
    face_id: int = Field(ge=0, le=0xFF, description="顔グラフィックID")
    source_work: int = Field(ge=0, le=0xFF, description="登場作品ID")
    affiliation: int = Field(ge=0, le=0xFF, description="所属（味方/敵）")
    defeat_exp: int = Field(ge=0, le=255, description="撃破時に得られる経験値")

    # 性格
    personality: Personality

    # 成長率（パックされたバイト）
    growth: GrowthRates

    # 地形適応
    terrain: TerrainProfile

    # 基礎ステータス
    melee_attack: int = Field(ge=0, le=255, description="近距離攻撃")
    ranged_attack: int = Field(ge=0, le=255, description="遠距離攻撃")
    accuracy: int = Field(ge=0, le=255, description="命中")
    skill: int = Field(ge=0, le=255, description="技量")
    evasion: int = Field(ge=0, le=255, description="回避")
    intuition: int = Field(ge=0, le=255, description="直感（130以上で2回行動）")
    sp: int = Field(ge=0, le=255, description="精神ポイント最大値")

    # 精神コマンド（最大6個、主人公は最大9まで mixed list）
    spirits: list[SpiritCommand] = Field(default_factory=list, max_length=9)

    # 特殊技能（最大3個、主人公は最大9まで mixed list）
    skills: list[SpecialSkill] = Field(default_factory=list, max_length=9)

    @field_validator("spirits")
    @classmethod
    def _check_spirits(cls, v: list[SpiritCommand]) -> list[SpiritCommand]:
        if len(v) > 9:
            raise ValueError("精神+技能の合計は9個まで")
        return v

    @field_validator("skills")
    @classmethod
    def _check_skills(cls, v: list[SpecialSkill]) -> list[SpecialSkill]:
        if len(v) > 9:
            raise ValueError("精神+技能の合計は9個まで")
        return v


class PilotCollection(BaseModel):
    """全パイロットデータ（YAML I/Oのルート型）"""
    rom_version: str = "V1.1"
    pilots: list[Pilot]
