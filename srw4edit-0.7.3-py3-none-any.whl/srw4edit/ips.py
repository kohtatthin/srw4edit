"""IPSパッチの生成（簡易実装）

IPSフォーマット仕様:
- ヘッダ: "PATCH" (5 bytes)
- レコード: offset(3 bytes BE) + size(2 bytes BE) + data(size bytes)
- フッタ: "EOF" (3 bytes)

このモジュールでは「個人利用前提」なので、差分を出力できれば十分。
"""

from __future__ import annotations

from pathlib import Path


def make_patch(original: bytes, modified: bytes) -> bytes:
    """2つのROMバイト列を比較してIPSパッチを生成"""
    if len(original) != len(modified):
        raise ValueError("ROMサイズが一致しません")

    patch = bytearray(b"PATCH")
    in_diff = False
    run_start = 0
    diff_bytes = bytearray()

    def flush_run():
        if not diff_bytes:
            return
        # IPSの3バイトオフセット制約に従う（max $FFFFFF = 16MB）
        if run_start >= 0x1000000:
            raise ValueError("IPSは16MB超のオフセット非対応")
        # オフセット 'EOF' (= 0x454F46) は予約値、回避処理は省略（個人利用前提）
        patch.extend(run_start.to_bytes(3, "big"))
        patch.extend(len(diff_bytes).to_bytes(2, "big"))
        patch.extend(bytes(diff_bytes))

    for i in range(len(original)):
        if original[i] != modified[i]:
            if not in_diff:
                run_start = i
                in_diff = True
            diff_bytes.append(modified[i])
        else:
            if in_diff:
                flush_run()
                diff_bytes.clear()
                in_diff = False

    if in_diff:
        flush_run()

    patch.extend(b"EOF")
    return bytes(patch)


def diff_bytes_summary(original: bytes, modified: bytes) -> dict:
    """差分のサマリ統計を返す"""
    diff_count = sum(1 for a, b in zip(original, modified) if a != b)
    ranges = []
    in_diff = False
    start = 0
    for i, (a, b) in enumerate(zip(original, modified)):
        if a != b:
            if not in_diff:
                start = i
                in_diff = True
        else:
            if in_diff:
                ranges.append((start, i))
                in_diff = False
    if in_diff:
        ranges.append((start, len(original)))

    return {
        "total_changed_bytes": diff_count,
        "num_ranges": len(ranges),
        "ranges": ranges[:20],  # 最初の20件
    }
