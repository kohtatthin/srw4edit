"""武器関連の Pydantic モデル。

V1.1 ROM 準拠。16B 固定長レコード。
フィールド定義は SFCGENEditor RomMap.xml に基づく。
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class WeaponTerrain(BaseModel):
    """武器の地形適応（4方向、各 2bit）"""
    model_config = ConfigDict(extra='forbid')
    air: str = Field(..., pattern=r'^[\-CBA]$', description='空')
    land: str = Field(..., pattern=r'^[\-CBA]$', description='陸')
    sea: str = Field(..., pattern=r'^[\-CBA]$', description='海')
    space: str = Field(..., pattern=r'^[\-CBA]$', description='宇')


class Weapon(BaseModel):
    """武器レコード（16B 固定）"""
    model_config = ConfigDict(extra='forbid')

    # メタ（read-only 推奨）
    offset: str = Field(..., description='ROMオフセット $BCE70 形式')
    weapon_id: int = Field(..., ge=0, le=1023, description='武器ID = 武器情報オフセット配列の通し番号')
    name: str = Field(..., description='武器名（外部CSV由来、参考表示）')

    # 0x00: 上位4bit=武器タイプ, 下位4bit=追加情報
    weapon_type: int = Field(..., ge=0, le=15, description='0=遠距離, 4=近距離, 8-8F=MAP, DE=修理, DF=補給 (上位4bit)')
    weapon_type_extra: int = Field(..., ge=0, le=15, description='下位4bit (詳細不明)')

    # 0x01: 属性ビットフラグ
    can_cutoff: bool = Field(..., description='切り払い対象')
    not_p_weapon: bool = Field(..., description='非P武器（移動後攻撃不可）')
    is_beam: bool = Field(..., description='ビーム属性')
    attr_low5: int = Field(..., ge=0, le=31, description='下位5bit（用途不明）')

    # 0x02-0x07
    dialog_id: int = Field(..., ge=0, le=255, description='セリフ情報')
    anime_id: int = Field(..., ge=0, le=65535, description='アニメID (2B LE)')
    power: int = Field(..., ge=0, le=65535, description='威力 (2B LE)')
    accuracy: int = Field(..., ge=-128, le=127, description='命中補正 (sint8)')

    # 0x08: 上位4bit=クリティカル, 下位4bit=改造費テーブルID
    critical: int = Field(..., ge=0, le=15, description='クリティカル補正テーブル参照 (0-15)')
    custom_cost_type: int = Field(..., ge=0, le=15, description='改造費用テーブル参照 (0-7)')

    # 0x09-0x0A
    range_min: int = Field(..., ge=0, le=255, description='最低射程')
    range_max: int = Field(..., ge=0, le=255, description='最大射程')

    # 0x0B
    terrain: WeaponTerrain

    # 0x0C-0x0F
    ammo: int = Field(..., ge=0, le=255, description='弾数')
    en_cost: int = Field(..., ge=0, le=255, description='消費EN')
    morale: int = Field(..., ge=0, le=255, description='必要気力')
    skill_req: int = Field(..., ge=0, le=255, description='必要技能')


class WeaponCollection(BaseModel):
    """全武器のコレクション（YAML I/O ルート型）"""
    model_config = ConfigDict(extra='forbid')
    rom_version: str = 'V1.1'
    weapons: list[Weapon]
