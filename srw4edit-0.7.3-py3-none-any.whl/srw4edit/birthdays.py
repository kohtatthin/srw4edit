"""主人公誕生日リスト（旧・謎2）の読み書き（2026-07-07 解読）

  0x0B8FE3: 14B×58
    byte0-11 : [精神ID, 習得Lv] × 6
    byte12-13: 0x0000 (予約、書き戻し時は保全)

  エントリ 0-47: 星座12 × 血液型4 (O/A/B/AB)
  エントリ 48-57: 特殊誕生日（歴代主人公。魂・奇跡持ちの強セット）
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

TABLE = 0x0B8FE3
COUNT = 58
RECORD = 14

_ZODIAC = ['3/21～4/19', '4/20～5/20', '5/21～6/21', '6/22～7/22', '7/23～8/22',
           '8/23～9/22', '9/23～10/23', '10/24～11/22', '11/23～12/21',
           '12/22～1/19', '1/20～2/18', '2/19～3/20']
_BLOOD = ['O', 'A', 'B', 'AB']
_SPECIAL = ['9/2 O型', '12/24 B型', '6/25 AB型', '4/29 A型', '3/13 B型',
            '4/11 O型', '8/12 A型', '11/16 AB型', '1/29 B型', '2/9 A型']

LABELS = [f'{_ZODIAC[i // 4]} {_BLOOD[i % 4]}型' for i in range(48)] + [f'特殊 {s}' for s in _SPECIAL]


class SpiritSlot(BaseModel):
    model_config = ConfigDict(extra='ignore')
    spirit_id: int = Field(..., ge=0, le=255, description='精神コマンドID (0-30)')
    level: int = Field(..., ge=0, le=255, description='習得Lv')


class Birthday(BaseModel):
    model_config = ConfigDict(extra='ignore')
    entry_id: int = Field(..., ge=0, le=57)
    label: str
    spirits: list[SpiritSlot] = Field(..., min_length=6, max_length=6)
    reserved_hex: str = Field(default='0000', description='byte12-13 生バイト（保全用）')


class BirthdayCollection(BaseModel):
    model_config = ConfigDict(extra='ignore')
    birthdays: list[Birthday]


def read_birthdays(rom: bytes) -> BirthdayCollection:
    out = []
    for i in range(COUNT):
        base = TABLE + i * RECORD
        spirits = [SpiritSlot(spirit_id=rom[base + k * 2], level=rom[base + k * 2 + 1])
                   for k in range(6)]
        out.append(Birthday(entry_id=i, label=LABELS[i], spirits=spirits,
                            reserved_hex=rom[base + 12:base + 14].hex()))
    return BirthdayCollection(birthdays=out)


def apply_birthdays(rom: bytes, coll: BirthdayCollection) -> bytes:
    out = bytearray(rom)
    for b in coll.birthdays:
        base = TABLE + b.entry_id * RECORD
        for k, s in enumerate(b.spirits[:6]):
            out[base + k * 2] = s.spirit_id
            out[base + k * 2 + 1] = s.level
        out[base + 12:base + 14] = bytes.fromhex(b.reserved_hex)
    return bytes(out)
