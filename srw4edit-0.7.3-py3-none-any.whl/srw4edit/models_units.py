"""ユニット関連のPydanticモデル追加（既存models.pyに追記する内容）"""

from __future__ import annotations
from pydantic import BaseModel, Field, ConfigDict


class TerrainRating(BaseModel):
    """地形適応 (-/D/C/B/A)"""
    model_config = ConfigDict(extra='forbid')
    air: str = Field(..., pattern=r'^[\-DCBA]$')
    sea: str = Field(..., pattern=r'^[\-DCBA]$')
    space: str = Field(..., pattern=r'^[\-DCBA]$')
    land: str = Field(..., pattern=r'^[\-DCBA]$')


class WeaponSlot(BaseModel):
    """ユニットが搭載する1武器のスロット (3B = 24bit)

    SFCGENEditor RomMap.xml より:
      bit 0-9   : 武器ID (武器情報オフセット配列のインデックス)
      bit 10-15 : 弾薬ID (0-63, 同じIDの武器同士で弾薬を共有する管理用)
      bit 16-23 : 改造ID (0-255, ユニットの改造段階に紐づく)
    """
    model_config = ConfigDict(extra='forbid')
    weapon_id: int = Field(..., ge=0, le=1023, description='武器ID (WID)')
    ammo_id: int = Field(..., ge=0, le=63, description='弾薬ID (AID)')
    custom_id: int = Field(..., ge=0, le=255, description='改造ID (CID)')


class Unit(BaseModel):
    """ユニットレコード（編集可能フィールド + メタ情報）"""
    model_config = ConfigDict(extra='forbid')

    # メタ（read-only）
    name: str = Field(..., description="参考名（ROM上のIDではない、編集不要）")
    offset: str = Field(..., description="ROMオフセット 16進表記 $XXXXXX")
    record_size: int = Field(..., description="レコードサイズ（バイト）")
    uid: int = Field(default=-1, description="ユニットID（情報オフセット配列のインデックス）")
    shared_uids: list[int] = Field(default_factory=list, description="同一レコードを共有する他のユニットID")
    is_enemy: bool = Field(default=False, description="敵専用機の目安（味方参考データに無い機体）")

    # 編集可能 - 基本ステータス
    hp: int = Field(..., ge=0, le=65535, description="HP")
    en: int = Field(..., ge=0, le=255, description="EN")
    armor: int = Field(..., ge=0, le=2550, description="装甲（実値、ROM格納は÷10）")
    mobility: int = Field(..., ge=0, le=255, description="運動性")
    limit_reaction: int = Field(..., ge=0, le=255, description="限界反応")
    move_range: int = Field(..., ge=0, le=255, description="移動力")
    move_type: int = Field(..., ge=0, le=255, description="移動タイプ (0陸/1空陸/2空/3水陸/4水陸空/5陸地中/6空陸地中/7水, それ以上は不明)")
    terrain: TerrainRating

    # 編集可能 - 戦闘外
    repair_cost: int = Field(..., ge=0, le=65535, description="修理費")
    reward_money: int = Field(..., ge=0, le=65535, description="獲得資金")

    # 編集可能 - メタ的フィールド
    fixed_pilot: int = Field(..., ge=0, le=255, description="固定パイロット番号")
    affiliation: int = Field(..., ge=0, le=255, description="所属")
    size_bgm: int = Field(..., ge=0, le=255, description="サイズ/BGM (前半=サイズ)")
    transform: int = Field(..., ge=0, le=255, description="変形")
    special_1: int = Field(..., ge=0, le=255, description="特殊能力1 (1の位9でHP回復)")
    special_2: int = Field(..., ge=0, le=255, description="特殊能力2 (10の位:1分身2盾3両 / 1の位:バリア)")
    team: int = Field(..., ge=0, le=255, description="チーム")

    # 編集不要だが保持
    icon: int = Field(..., ge=0, le=255)
    source_work: int = Field(..., ge=0, le=255)
    graphic: int = Field(..., ge=0, le=65535)
    weapon_count_field: int = Field(..., ge=0, le=255, description="武器数フィールド（実武器数と不一致あり）")
    unknown_31: int = Field(..., ge=0, le=255)

    # 未知バイト（11-15: 5バイト）は生バイトで保持
    unknown_11_15_hex: str = Field(..., description="offset 11-15 の生バイト (10桁hex)")

    # 武器セクション（offset 32 以降）
    weapon_slots: list[WeaponSlot] = Field(default_factory=list, description="搭載武器スロット (3B/武器)")
    weapon_extra_hex: str = Field(default='', description="武器スロット列末尾の余りバイト (hex、ない場合は空、00 00 sentinel は含まない)")
    sentinel: bool = Field(default=True, description="レコード末尾に 00 00 sentinel を持つか")


class UnitCollection(BaseModel):
    """全ユニットのコレクション"""
    model_config = ConfigDict(extra='forbid')
    units: list[Unit]
