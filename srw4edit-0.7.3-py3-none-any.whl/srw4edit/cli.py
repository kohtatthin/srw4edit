"""srw4edit のコマンドラインインターフェース"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from . import ips as ips_mod
from . import pilots as pilots_mod
from .rom import load_rom

app = typer.Typer(
    name="srw4edit",
    help="第4次スーパーロボット大戦（V1.1）ROM編集エディタ",
    no_args_is_help=True,
)

pilot_app = typer.Typer(name="pilot", help="パイロットデータ操作")
patch_app = typer.Typer(name="patch", help="IPSパッチ生成")

app.add_typer(pilot_app)
app.add_typer(patch_app)

console = Console()


@pilot_app.command("dump")
def pilot_dump(
    rom: Path = typer.Option(..., "--rom", help="ROMファイル"),
    out: Path = typer.Option(Path("pilots.yaml"), "--out", help="出力YAMLパス"),
):
    """ROMから全パイロットデータをYAML出力"""
    pilots_mod.dump_to_yaml(rom, out)
    console.print(f"[green]✓[/green] {out} に書き出しました")


@pilot_app.command("apply")
def pilot_apply(
    rom: Path = typer.Option(..., "--rom", help="元ROMファイル"),
    in_: Path = typer.Option(..., "--in", help="入力YAMLパス"),
    out: Path = typer.Option(..., "--out", help="出力ROMパス"),
):
    """YAMLの内容をROMに書き戻し、新ROMを生成"""
    pilots_mod.apply_from_yaml(rom, in_, out)
    console.print(f"[green]✓[/green] {out} に新ROMを書き出しました")


@pilot_app.command("show")
def pilot_show(
    rom: Path = typer.Option(..., "--rom", help="ROMファイル"),
    name: str = typer.Option(..., "--name", help="パイロット名（例: アムロ）"),
):
    """特定パイロットの内容を表示"""
    rom_data = load_rom(rom)
    offsets = pilots_mod._pilot_offsets()
    if name not in offsets:
        console.print(f"[red]エラー:[/red] {name} はオフセット表にありません")
        console.print(f"利用可能: {', '.join(list(offsets.keys())[:10])}...")
        raise typer.Exit(1)

    pilot = pilots_mod.read_pilot_at(rom_data, offsets[name], name=name)
    table = Table(title=f"{name} (offset: ${pilot.rom_offset:06X})", show_header=False)
    table.add_column("項目", style="cyan")
    table.add_column("値")
    table.add_row("近攻撃", str(pilot.melee_attack))
    table.add_row("遠攻撃", str(pilot.ranged_attack))
    table.add_row("命中", str(pilot.accuracy))
    table.add_row("技量", str(pilot.skill))
    table.add_row("回避", str(pilot.evasion))
    table.add_row("直感", f"{pilot.intuition}{'（2回行動可）' if pilot.intuition >= 130 else ''}")
    table.add_row("SP", str(pilot.sp))
    table.add_row("撃破時EXP", str(pilot.defeat_exp))
    table.add_row(
        "地形 (空/陸/海/宇)",
        f"{pilot.terrain.air.value}/{pilot.terrain.land.value}/"
        f"{pilot.terrain.sea.value}/{pilot.terrain.space.value}",
    )
    table.add_row(
        "精神コマンド",
        ", ".join(f"{s.name}({s.learn_level})" for s in pilot.spirits),
    )
    table.add_row(
        "特殊技能",
        ", ".join(f"{s.name}Lv{s.skill_level}({s.learn_level})" for s in pilot.skills),
    )
    console.print(table)


@pilot_app.command("list")
def pilot_list(
    rom: Path = typer.Option(..., "--rom", help="ROMファイル"),
):
    """全パイロットの簡易一覧"""
    rom_data = load_rom(rom)
    collection = pilots_mod.read_all_pilots(rom_data)
    table = Table(title=f"パイロット一覧 ({len(collection.pilots)}件)")
    table.add_column("名前", style="cyan")
    table.add_column("オフセット")
    table.add_column("近")
    table.add_column("遠")
    table.add_column("回避")
    table.add_column("直感")
    table.add_column("SP")
    table.add_column("精神")
    for p in collection.pilots:
        spirits = "/".join(s.name for s in p.spirits)
        table.add_row(
            p.name,
            f"${p.rom_offset:06X}",
            str(p.melee_attack),
            str(p.ranged_attack),
            str(p.evasion),
            str(p.intuition),
            str(p.sp),
            spirits[:30] + ("..." if len(spirits) > 30 else ""),
        )
    console.print(table)


@patch_app.command("make")
def patch_make(
    original: Path = typer.Option(..., "--original", help="元ROM"),
    modified: Path = typer.Option(..., "--modified", help="改造済ROM"),
    out: Path = typer.Option(Path("patch.ips"), "--out", help="出力IPSパス"),
):
    """元ROMと改造ROMの差分からIPSパッチを生成"""
    orig = load_rom(original)
    mod = load_rom(modified)
    summary = ips_mod.diff_bytes_summary(orig, mod)
    console.print(f"変更バイト数: {summary['total_changed_bytes']}")
    console.print(f"変更レンジ数: {summary['num_ranges']}")
    patch = ips_mod.make_patch(orig, mod)
    out.write_bytes(patch)
    console.print(f"[green]✓[/green] {out} にIPSパッチを書き出しました ({len(patch)} bytes)")


if __name__ == "__main__":
    app()
