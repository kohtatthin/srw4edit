"""武器データテーブルの読み書き

V1.1 ROM 準拠。16B 固定長レコード × 649 個。
フィールド構造は SFCGENEditor RomMap.xml に準拠。

テーブル構造:
- 武器情報オフセット配列 (0xBC950-0xBCE6F, 2B × 656): WID → 武器データオフセット
- 武器データ           (0xBCE70-0xBF6FF, 16B × 649): 実際の武器ステータス
"""

from __future__ import annotations

import csv
import importlib.resources as resources
import struct
from typing import Any

import yaml

from .models_weapons import Weapon, WeaponCollection


WEAPON_PTR_START = 0xBC950
WEAPON_PTR_END = 0xBCE6F
WEAPON_PTR_COUNT = (WEAPON_PTR_END - WEAPON_PTR_START + 1) // 2  # 656

WEAPON_DATA_START = 0xBCE70
WEAPON_DATA_END = 0xBF6FF
WEAPON_RECORD_SIZE = 16
WEAPON_DATA_COUNT = (WEAPON_DATA_END - WEAPON_DATA_START + 1) // WEAPON_RECORD_SIZE  # 649

ROM_BANK_BASE = 0x0B0000  # ROM内バンク $0B のベース

ADAPT_VAL_TO_RANK = {0: '-', 1: 'C', 2: 'B', 3: 'A'}
ADAPT_RANK_TO_VAL = {v: k for k, v in ADAPT_VAL_TO_RANK.items()}


def _load_weapon_names() -> dict[int, str]:
    """同梱 weapon_names_v11.csv から「武器データオフセット → 武器名」マップを構築"""
    pkg = resources.files('srw4edit.data')
    text = (pkg / 'weapon_names_v11.csv').read_text(encoding='shift_jis')
    result: dict[int, str] = {}
    for row in csv.reader(text.splitlines()):
        if len(row) < 2:
            continue
        try:
            off = int(row[0], 16)
        except ValueError:
            continue
        result[off] = row[1]
    return result


def parse_weapon_record(data: bytes) -> dict[str, Any]:
    """16B 武器レコード → dict"""
    assert len(data) == WEAPON_RECORD_SIZE
    b0, b1, b8, b11 = data[0], data[1], data[8], data[11]
    accuracy = data[7] if data[7] < 128 else data[7] - 256
    return {
        'weapon_type': (b0 >> 4) & 0xF,
        'weapon_type_extra': b0 & 0xF,
        'can_cutoff': bool((b1 >> 5) & 1),
        'not_p_weapon': bool((b1 >> 6) & 1),
        'is_beam': bool((b1 >> 7) & 1),
        'attr_low5': b1 & 0x1F,
        'dialog_id': data[2],
        'anime_id': struct.unpack('<H', data[3:5])[0],
        'power': struct.unpack('<H', data[5:7])[0],
        'accuracy': accuracy,
        'critical': (b8 >> 4) & 0xF,
        'custom_cost_type': b8 & 0xF,
        'range_min': data[9],
        'range_max': data[10],
        'terrain': {
            'air': ADAPT_VAL_TO_RANK[(b11 >> 2) & 0x3],
            'land': ADAPT_VAL_TO_RANK[(b11 >> 4) & 0x3],
            'sea': ADAPT_VAL_TO_RANK[(b11 >> 6) & 0x3],
            'space': ADAPT_VAL_TO_RANK[b11 & 0x3],
        },
        'ammo': data[12],
        'en_cost': data[13],
        'morale': data[14],
        'skill_req': data[15],
    }


def serialize_weapon_record(w: Weapon) -> bytes:
    """Weapon → 16B"""
    b0 = ((w.weapon_type & 0xF) << 4) | (w.weapon_type_extra & 0xF)
    b1 = (
        ((1 if w.is_beam else 0) << 7)
        | ((1 if w.not_p_weapon else 0) << 6)
        | ((1 if w.can_cutoff else 0) << 5)
        | (w.attr_low5 & 0x1F)
    )
    b8 = ((w.critical & 0xF) << 4) | (w.custom_cost_type & 0xF)
    b11 = (
        ((ADAPT_RANK_TO_VAL[w.terrain.sea] & 0x3) << 6)
        | ((ADAPT_RANK_TO_VAL[w.terrain.land] & 0x3) << 4)
        | ((ADAPT_RANK_TO_VAL[w.terrain.air] & 0x3) << 2)
        | (ADAPT_RANK_TO_VAL[w.terrain.space] & 0x3)
    )
    acc_byte = w.accuracy if w.accuracy >= 0 else w.accuracy + 256
    return bytes([
        b0, b1, w.dialog_id,
        w.anime_id & 0xFF, (w.anime_id >> 8) & 0xFF,
        w.power & 0xFF, (w.power >> 8) & 0xFF,
        acc_byte, b8,
        w.range_min, w.range_max, b11,
        w.ammo, w.en_cost, w.morale, w.skill_req,
    ])


def read_weapon_ptr_table(rom: bytes) -> list[int]:
    """武器情報オフセット配列をパース。各要素はバンク内アドレス (0x0000-0xFFFF)。"""
    ptrs: list[int] = []
    for i in range(WEAPON_PTR_COUNT):
        off = WEAPON_PTR_START + i * 2
        ptrs.append(struct.unpack('<H', rom[off:off + 2])[0])
    return ptrs


def dump_weapons(rom: bytes) -> WeaponCollection:
    """全武器をパース。武器情報オフセット配列を辿り、武器データを取得。"""
    names = _load_weapon_names()
    ptrs = read_weapon_ptr_table(rom)
    weapons: list[Weapon] = []

    for wid, ptr in enumerate(ptrs):
        full_off = ROM_BANK_BASE | ptr
        if not (WEAPON_DATA_START <= full_off <= WEAPON_DATA_END):
            continue
        if (full_off - WEAPON_DATA_START) % WEAPON_RECORD_SIZE != 0:
            continue
        data = rom[full_off:full_off + WEAPON_RECORD_SIZE]
        if len(data) != WEAPON_RECORD_SIZE:
            continue
        parsed = parse_weapon_record(data)
        parsed['offset'] = f'${full_off:05X}'
        parsed['weapon_id'] = wid
        parsed['name'] = names.get(full_off, f'(unknown_${full_off:05X})')
        weapons.append(Weapon.model_validate(parsed))

    return WeaponCollection(weapons=weapons)


def apply_weapons(rom: bytes, coll: WeaponCollection) -> bytes:
    """編集後の WeaponCollection を ROM に書き戻し。
    武器情報オフセット配列はそのまま、武器データテーブルのみ更新する。
    """
    new_rom = bytearray(rom)
    written: set[int] = set()
    for w in coll.weapons:
        full_off = int(w.offset.lstrip('$'), 16)
        if not (WEAPON_DATA_START <= full_off <= WEAPON_DATA_END):
            raise ValueError(f'{w.name}: オフセット ${full_off:05X} が武器テーブル範囲外')
        if full_off in written:
            # 共用エントリ：複数 WID から同じ武器を指している場合、最初の書き込みを優先（同じ値なら問題ない）
            existing = bytes(new_rom[full_off:full_off + WEAPON_RECORD_SIZE])
            rec = serialize_weapon_record(w)
            if rec != existing:
                raise ValueError(f'{w.name}: ${full_off:05X} に既に異なる内容が書き込まれている（共用エントリの矛盾）')
            continue
        new_rom[full_off:full_off + WEAPON_RECORD_SIZE] = serialize_weapon_record(w)
        written.add(full_off)
    return bytes(new_rom)


def dump_to_yaml(rom: bytes) -> str:
    coll = dump_weapons(rom)
    return yaml.safe_dump(coll.model_dump(), allow_unicode=True, sort_keys=False, width=200)


def apply_from_yaml(rom: bytes, yaml_str: str) -> bytes:
    data = yaml.safe_load(yaml_str)
    coll = WeaponCollection.model_validate(data)
    return apply_weapons(rom, coll)
