"""ROM内テキストの復号（2026-07-07 解読の文字コード表による）

符号仕様:
  0x00-0x3F : ラテン/数字/記号/合字
  0x40-0x8B : ひらがな
  0x90-0xEB : カタカナ
  0xEC 0xED : "(MAP)" / 0xEE: "(B)" / 0xEF: "(P)"
  0xF0-0xFA : 2バイト漢字 (バンク+インデックス)
  0xFB xx 80: 主人公機名の差し替え
  0xFF      : 終端
"""

from __future__ import annotations

import importlib.resources as resources
import json
import struct

_CHARMAP: dict | None = None


def _charmap() -> dict:
    global _CHARMAP
    if _CHARMAP is None:
        text = (resources.files('srw4edit.data') / 'charmap.json').read_text(encoding='utf-8')
        raw = json.loads(text)
        _CHARMAP = {
            'single': {int(k, 16): v for k, v in raw['single'].items()},
            'kanji': {(int(k[2:4], 16), int(k[4:6], 16)): v for k, v in raw['kanji'].items()},
        }
    return _CHARMAP


def decode_string(rom: bytes, offset: int, max_len: int = 40) -> str:
    """offset から 0xFF 終端までを復号"""
    cm = _charmap()
    out: list[str] = []
    p = offset
    while rom[p] != 0xFF and p - offset < max_len:
        x = rom[p]
        if x == 0xEE:
            out.append('(B)'); p += 1
        elif x == 0xEF:
            out.append('(P)'); p += 1
        elif x == 0xEC and rom[p + 1] == 0xED:
            out.append('(MAP)'); p += 2
        elif x == 0xFB:
            out.append(f'[主人公機{rom[p + 1]:02X}]'); p += 3
        elif 0xF0 <= x <= 0xFA:
            out.append(cm['kanji'].get((x, rom[p + 1]), f'[{x:02X}{rom[p + 1]:02X}]')); p += 2
        else:
            out.append(cm['single'].get(x, f'[{x:02X}]')); p += 1
    return ''.join(out)


def _read_ptr_names(rom: bytes, arrays: list[int], base: int, count: int) -> list[str]:
    names = []
    for i in range(count):
        arr = arrays[i // 0x100]
        ptr = struct.unpack_from('<H', rom, arr + (i % 0x100) * 2)[0]
        names.append(decode_string(rom, base + ptr))
    return names


def unit_names_from_rom(rom: bytes, count: int = 0x12F) -> list[str]:
    """ユニット名 (ID順)。配列 0x126050/0x126250, +0x120000"""
    return _read_ptr_names(rom, [0x126050, 0x126250], 0x120000, count)


def weapon_names_from_rom(rom: bytes, count: int = 0x290) -> list[str]:
    """武器名 (WID順)。配列 0x0C7760/0x0C7960/0x0C7B60, +0x0C0000"""
    return _read_ptr_names(rom, [0x0C7760, 0x0C7960, 0x0C7B60], 0x0C0000, count)


def pilot_names_from_rom(rom: bytes, count: int = 0x11D) -> list[str]:
    """パイロット名 (PID順)。配列 0x126B34, +0x120000"""
    return _read_ptr_names(rom, [0x126B34, 0x126B34 + 0x200], 0x120000, count)
